﻿
namespace GestioneFile
{
    partial class frmMain
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.flpPulsanti = new System.Windows.Forms.FlowLayoutPanel();
            this.btnCrea = new System.Windows.Forms.Button();
            this.gpxCreaBottoni = new System.Windows.Forms.GroupBox();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.btnCreaBottone = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnElimina = new System.Windows.Forms.Button();
            this.gbxElimina = new System.Windows.Forms.GroupBox();
            this.btnEliminaBottone = new System.Windows.Forms.Button();
            this.txtNomeElimina = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbxPercorso = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPer = new System.Windows.Forms.TextBox();
            this.btnIcona = new System.Windows.Forms.Button();
            this.gpxCreaBottoni.SuspendLayout();
            this.gbxElimina.SuspendLayout();
            this.SuspendLayout();
            // 
            // flpPulsanti
            // 
            this.flpPulsanti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpPulsanti.BackColor = System.Drawing.SystemColors.ControlLight;
            this.flpPulsanti.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.flpPulsanti.Location = new System.Drawing.Point(404, 13);
            this.flpPulsanti.Name = "flpPulsanti";
            this.flpPulsanti.Size = new System.Drawing.Size(750, 465);
            this.flpPulsanti.TabIndex = 0;
            // 
            // btnCrea
            // 
            this.btnCrea.Location = new System.Drawing.Point(13, 13);
            this.btnCrea.Name = "btnCrea";
            this.btnCrea.Size = new System.Drawing.Size(120, 35);
            this.btnCrea.TabIndex = 1;
            this.btnCrea.Text = "Crea un bottone";
            this.btnCrea.UseVisualStyleBackColor = true;
            this.btnCrea.Click += new System.EventHandler(this.btnCrea_Click);
            // 
            // gpxCreaBottoni
            // 
            this.gpxCreaBottoni.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gpxCreaBottoni.Controls.Add(this.txtPath);
            this.gpxCreaBottoni.Controls.Add(this.btnCreaBottone);
            this.gpxCreaBottoni.Controls.Add(this.label2);
            this.gpxCreaBottoni.Controls.Add(this.txtNome);
            this.gpxCreaBottoni.Controls.Add(this.label1);
            this.gpxCreaBottoni.Enabled = false;
            this.gpxCreaBottoni.Location = new System.Drawing.Point(13, 379);
            this.gpxCreaBottoni.Name = "gpxCreaBottoni";
            this.gpxCreaBottoni.Size = new System.Drawing.Size(385, 114);
            this.gpxCreaBottoni.TabIndex = 2;
            this.gpxCreaBottoni.TabStop = false;
            this.gpxCreaBottoni.Text = "Crea bottone";
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(10, 85);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(249, 20);
            this.txtPath.TabIndex = 5;
            // 
            // btnCreaBottone
            // 
            this.btnCreaBottone.Location = new System.Drawing.Point(265, 61);
            this.btnCreaBottone.Name = "btnCreaBottone";
            this.btnCreaBottone.Size = new System.Drawing.Size(114, 45);
            this.btnCreaBottone.TabIndex = 4;
            this.btnCreaBottone.Text = "Crea il bottone";
            this.btnCreaBottone.UseVisualStyleBackColor = true;
            this.btnCreaBottone.Click += new System.EventHandler(this.btnCreaBottone_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Percorso del file";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(10, 37);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(249, 20);
            this.txtNome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome del bottone";
            // 
            // btnElimina
            // 
            this.btnElimina.Location = new System.Drawing.Point(272, 13);
            this.btnElimina.Name = "btnElimina";
            this.btnElimina.Size = new System.Drawing.Size(120, 35);
            this.btnElimina.TabIndex = 3;
            this.btnElimina.Text = "Elimina un bottone";
            this.btnElimina.UseVisualStyleBackColor = true;
            this.btnElimina.Click += new System.EventHandler(this.btnElimina_Click);
            // 
            // gbxElimina
            // 
            this.gbxElimina.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gbxElimina.Controls.Add(this.btnEliminaBottone);
            this.gbxElimina.Controls.Add(this.txtNomeElimina);
            this.gbxElimina.Controls.Add(this.label3);
            this.gbxElimina.Enabled = false;
            this.gbxElimina.Location = new System.Drawing.Point(13, 281);
            this.gbxElimina.Name = "gbxElimina";
            this.gbxElimina.Size = new System.Drawing.Size(385, 100);
            this.gbxElimina.TabIndex = 4;
            this.gbxElimina.TabStop = false;
            this.gbxElimina.Text = "Elimina bottone";
            // 
            // btnEliminaBottone
            // 
            this.btnEliminaBottone.Location = new System.Drawing.Point(10, 64);
            this.btnEliminaBottone.Name = "btnEliminaBottone";
            this.btnEliminaBottone.Size = new System.Drawing.Size(101, 23);
            this.btnEliminaBottone.TabIndex = 7;
            this.btnEliminaBottone.Text = "Elimina il bottone";
            this.btnEliminaBottone.UseVisualStyleBackColor = true;
            this.btnEliminaBottone.Click += new System.EventHandler(this.btnEliminaBottone_Click);
            // 
            // txtNomeElimina
            // 
            this.txtNomeElimina.Location = new System.Drawing.Point(10, 37);
            this.txtNomeElimina.Name = "txtNomeElimina";
            this.txtNomeElimina.Size = new System.Drawing.Size(369, 20);
            this.txtNomeElimina.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nome del bottone";
            // 
            // cbxPercorso
            // 
            this.cbxPercorso.AutoSize = true;
            this.cbxPercorso.Location = new System.Drawing.Point(12, 260);
            this.cbxPercorso.Name = "cbxPercorso";
            this.cbxPercorso.Size = new System.Drawing.Size(204, 17);
            this.cbxPercorso.TabIndex = 8;
            this.cbxPercorso.Text = "Ottieni il percorso del bottone premuto";
            this.cbxPercorso.UseVisualStyleBackColor = true;
            this.cbxPercorso.CheckedChanged += new System.EventHandler(this.cbxPercorso_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(404, 483);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Percorso:";
            // 
            // txtPer
            // 
            this.txtPer.Enabled = false;
            this.txtPer.Location = new System.Drawing.Point(463, 480);
            this.txtPer.Name = "txtPer";
            this.txtPer.ReadOnly = true;
            this.txtPer.Size = new System.Drawing.Size(691, 20);
            this.txtPer.TabIndex = 10;
            // 
            // btnIcona
            // 
            this.btnIcona.Location = new System.Drawing.Point(140, 13);
            this.btnIcona.Name = "btnIcona";
            this.btnIcona.Size = new System.Drawing.Size(126, 35);
            this.btnIcona.TabIndex = 11;
            this.btnIcona.Text = "Aggiungi icona";
            this.btnIcona.UseVisualStyleBackColor = true;
            this.btnIcona.Click += new System.EventHandler(this.btnIcona_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 503);
            this.Controls.Add(this.btnIcona);
            this.Controls.Add(this.txtPer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbxPercorso);
            this.Controls.Add(this.gbxElimina);
            this.Controls.Add(this.btnElimina);
            this.Controls.Add(this.gpxCreaBottoni);
            this.Controls.Add(this.btnCrea);
            this.Controls.Add(this.flpPulsanti);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Leave += new System.EventHandler(this.Form1_Leave);
            this.gpxCreaBottoni.ResumeLayout(false);
            this.gpxCreaBottoni.PerformLayout();
            this.gbxElimina.ResumeLayout(false);
            this.gbxElimina.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpPulsanti;
        private System.Windows.Forms.Button btnCrea;
        private System.Windows.Forms.Button btnCreaBottone;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEliminaBottone;
        private System.Windows.Forms.TextBox txtNomeElimina;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.GroupBox gbxElimina;
        private System.Windows.Forms.TextBox txtPath;
        public System.Windows.Forms.GroupBox gpxCreaBottoni;
        public System.Windows.Forms.CheckBox cbxPercorso;
        private System.Windows.Forms.Button btnElimina;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txtPer;
        private System.Windows.Forms.Button btnIcona;
    }
}

