﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GestioneFile
{
    public partial class FormIcona : Form
    {
        
        public FormIcona()
        {
            InitializeComponent();
        }

        private void btnSelezionaIcona_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofdCaricaImmagine = new OpenFileDialog())
            {
                ofdCaricaImmagine.Filter = "File ICO (*.ico) | *.ico | Tutti i file | *.*";
                ofdCaricaImmagine.FilterIndex = 1;
                ofdCaricaImmagine.RestoreDirectory = true;
                if (ofdCaricaImmagine.ShowDialog() == DialogResult.OK)
                {
                    lblPercorsoIcona.Text = ofdCaricaImmagine.FileName;
                }
            }
        }

        private void lblShowPath_Click(object sender, EventArgs e)
        {
            
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            if(txtNomeBtn.Text != "" && lblPercorsoIcona.Text != "")
            {
                Close();
            }
            else
            {
                MessageBox.Show("Prima inserisci un nome per il bottone da cambiare e una icona da usare");
            }
        }
    }
}
