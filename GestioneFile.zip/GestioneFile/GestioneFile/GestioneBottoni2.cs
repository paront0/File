﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;

namespace GestioneFile
{
    public class GestioneBottoni2
    {
        
        public string Nome { get; set; }
        public string Percorso { get; set; }       
        public int Altezza { get; set; }
        
        public int Larghezza { get; set; }

        public GestioneBottoni2()
        { }

        public GestioneBottoni2(string nome, string percorso, int altezza, int larghezza)
        {
            Nome = nome;
            Percorso = percorso;
            Altezza = altezza;
            Larghezza = larghezza;
        }
        public string getPercorso
        {
            get
            {
                return Percorso;
            }
        }

        public Button CreaBottone(FlowLayoutPanel parent)
        {
            Button b = new Button();
            b.Text = Nome;
            b.Width = Larghezza;
            b.Height = Altezza;
            b.Click += B_Click;
            b.Parent = parent;
            b.AutoSize = false;
            return b;
        }

        private void B_Click(object sender, EventArgs e)
        {
            frmMain frmmain = (frmMain)frmMain.ActiveForm;
            try
            {
                if(frmmain.cbxPercorso.Checked == true)
                {
                    frmmain.txtPer.Enabled = true;
                    frmmain.txtPer.Text = Percorso;
                }
                else
                    Process.Start(Percorso);
            }
            catch
            {
                MessageBox.Show("errore nel percorso del pulsante");
            }
        }
    }
}
