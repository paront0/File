﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace GestioneFile
{
    public class GestioneBottoni
    {
        string percorso;
        string nome;
        int altezza, larghezza;
        static int idBottone = 0;
        
        public GestioneBottoni()
        { }
        
        public GestioneBottoni(string nome, string percorso, int altezza, int larghezza)
        {
            this.nome = nome;
            this.percorso = percorso;
            this.altezza = altezza;
            this.larghezza = larghezza;
        }
        
        public Button CreaBottone()
        {
            Button b = new Button();
            b.Text = nome;
            int id = idBottone++;
            b.Width = larghezza;
            b.Height = altezza;
            b.Click += B_Click;
            return b;
        }

        private void B_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(percorso);
            }
            catch
            {
                MessageBox.Show("errore nel percorso del pulsante");
            }
        }
        
        public string GetNome
        {
            get
            {
                return nome;
            }
        }
    }
}
