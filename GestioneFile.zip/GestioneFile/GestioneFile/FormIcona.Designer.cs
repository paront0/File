﻿
namespace GestioneFile
{
    partial class FormIcona
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNomeBtn = new System.Windows.Forms.TextBox();
            this.btnSelezionaIcona = new System.Windows.Forms.Button();
            this.lblPercorsoIcona = new System.Windows.Forms.Label();
            this.lblShowPath = new System.Windows.Forms.Label();
            this.btnChange = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome del bottone";
            // 
            // txtNomeBtn
            // 
            this.txtNomeBtn.Location = new System.Drawing.Point(16, 30);
            this.txtNomeBtn.Name = "txtNomeBtn";
            this.txtNomeBtn.Size = new System.Drawing.Size(166, 20);
            this.txtNomeBtn.TabIndex = 1;
            // 
            // btnSelezionaIcona
            // 
            this.btnSelezionaIcona.Location = new System.Drawing.Point(16, 57);
            this.btnSelezionaIcona.Name = "btnSelezionaIcona";
            this.btnSelezionaIcona.Size = new System.Drawing.Size(166, 28);
            this.btnSelezionaIcona.TabIndex = 2;
            this.btnSelezionaIcona.Text = "Seleziona icona";
            this.btnSelezionaIcona.UseVisualStyleBackColor = true;
            this.btnSelezionaIcona.Click += new System.EventHandler(this.btnSelezionaIcona_Click);
            // 
            // lblPercorsoIcona
            // 
            this.lblPercorsoIcona.AutoSize = true;
            this.lblPercorsoIcona.Location = new System.Drawing.Point(16, 92);
            this.lblPercorsoIcona.Name = "lblPercorsoIcona";
            this.lblPercorsoIcona.Size = new System.Drawing.Size(96, 13);
            this.lblPercorsoIcona.TabIndex = 3;
            this.lblPercorsoIcona.Text = "Percorso dell\'icona";
            // 
            // lblShowPath
            // 
            this.lblShowPath.AutoSize = true;
            this.lblShowPath.Location = new System.Drawing.Point(16, 105);
            this.lblShowPath.Name = "lblShowPath";
            this.lblShowPath.Size = new System.Drawing.Size(16, 13);
            this.lblShowPath.TabIndex = 4;
            this.lblShowPath.Text = "...";
            this.lblShowPath.Click += new System.EventHandler(this.lblShowPath_Click);
            // 
            // btnChange
            // 
            this.btnChange.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnChange.Location = new System.Drawing.Point(16, 122);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(88, 23);
            this.btnChange.TabIndex = 5;
            this.btnChange.Text = "Cambia icona";
            this.btnChange.UseVisualStyleBackColor = true;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // FormIcona
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.lblShowPath);
            this.Controls.Add(this.lblPercorsoIcona);
            this.Controls.Add(this.btnSelezionaIcona);
            this.Controls.Add(this.txtNomeBtn);
            this.Controls.Add(this.label1);
            this.Name = "FormIcona";
            this.Text = "FormIcona";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSelezionaIcona;
        private System.Windows.Forms.Label lblPercorsoIcona;
        public System.Windows.Forms.TextBox txtNomeBtn;
        public System.Windows.Forms.Label lblShowPath;
        public System.Windows.Forms.Button btnChange;
    }
}