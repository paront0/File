﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Xsl;

namespace GestioneFile
{
    public partial class frmMain : Form
    {
        List<GestioneBottoni2> listaBottoni = new List<GestioneBottoni2>();
        GestioneBottoni2 GB = null;
        FormIcona frmIcona = new FormIcona();

        public frmMain()
        {
            InitializeComponent();
        }
        public bool valuta => cbxPercorso.Checked;

        private void btnCrea_Click(object sender, EventArgs e)
        {
            gpxCreaBottoni.Enabled = true;
            gbxElimina.Enabled = false;
        }

        private void btnElimina_Click(object sender, EventArgs e)
        {
            gbxElimina.Enabled = true;
            gpxCreaBottoni.Enabled = false;
        }

        private void btnCreaBottone_Click(object sender, EventArgs e)
        {
            GB = new GestioneBottoni2(txtNome.Text, txtPath.Text, flpPulsanti.Height/8, flpPulsanti.Width/6);
            GB.CreaBottone(flpPulsanti);
            listaBottoni.Add(GB);
            txtPath.Text = "";
            txtNome.Text = "";
            Save();
        }

        private void btnEliminaBottone_Click(object sender, EventArgs e)
        {

            try
            {
                bool eliminato = false;
                for (int i = 0; i < listaBottoni.Count && eliminato == false; i++)
                {
                    if (listaBottoni[i].Nome == txtNomeElimina.Text)
                    {
                        eliminato = true;
                        flpPulsanti.Controls.RemoveAt(i);
                        listaBottoni.Remove(listaBottoni[i]);
                    }
                }
                if (eliminato == false)
                    MessageBox.Show("Bottone inesistente o nome errato");
                txtNomeElimina.Text = "";
                Save();
            }
            catch
            {
                MessageBox.Show("Bottone inesistente o nome errato");
                txtNomeElimina.Text = "";
            }
        }

        void Save()
        {
            using (var fileStream = new FileStream(@"C:\Users\dalbo\OneDrive\Desktop\app\GestioneFile\GestioneFile\bin\Debug\save.xml", FileMode.Create))
            {
                var serializer = new XmlSerializer(typeof(List<GestioneBottoni2>));
                serializer.Serialize(fileStream, listaBottoni);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (FileStream f = new FileStream(@"C:\Users\dalbo\OneDrive\Desktop\app\GestioneFile\GestioneFile\bin\Debug\save.xml", FileMode.Open))
            {
                XmlSerializer sr = new XmlSerializer(typeof(List<GestioneBottoni2>));
                listaBottoni = (List<GestioneBottoni2>)sr.Deserialize(f);

                // ricreo i pulsanti caricati da file
                flpPulsanti.Controls.Clear();
                foreach (GestioneBottoni2 gb in listaBottoni)
                    gb.CreaBottone(flpPulsanti);
            }
        }

        private void Form1_Leave(object sender, EventArgs e)
        {
            Save();
        }

        private void cbxPercorso_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxPercorso.Checked == true)
                txtPer.Enabled = true;
            else
            {
                txtPer.Text = "";
                txtPer.Enabled = false;
            }
        }

        private void btnIcona_Click(object sender, EventArgs e)
        {
            frmIcona.ShowDialog();
            frmIcona.txtNomeBtn.Text = "";
            frmIcona.lblShowPath.Text = "";
            
        }
    }
}
